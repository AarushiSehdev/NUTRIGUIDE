package com.example.nutrition_app_gdsc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
