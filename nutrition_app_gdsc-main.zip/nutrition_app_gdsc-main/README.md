# nutrition_app_gdsc

A project to teach GDSC IGDTUW Flutter's Circle about API calls in Flutter. This app shows nutrition composition of a food item.

![image](https://user-images.githubusercontent.com/78756272/215520075-c2079f1c-28fc-4b5e-8e9f-06da7fb7a264.png)
